window.onload = () => {
    let produto: loja.Produto | null = null; 
  
    
    const nomeInput = document.getElementById("nomeProduto") as HTMLInputElement;
    const precoInput = document.getElementById("precoProduto") as HTMLInputElement;
    const nomeElemento = document.getElementById("produtoNome") as HTMLElement;
    const precoElemento = document.getElementById("produtoPreco") as HTMLElement;
    const inputImposto = document.getElementById("inputImposto") as HTMLInputElement;
    const botaoCadastrar = document.getElementById("cadastrarProduto") as HTMLButtonElement;
    const botaoCalcular = document.getElementById("calcularPreco") as HTMLButtonElement;
    const precoFinalElemento = document.getElementById("precoFinal") as HTMLElement;
  
    
    botaoCadastrar.onclick = () => {
      const nome = nomeInput.value.trim();
      const preco = parseFloat(precoInput.value.trim());
  
      if (nome && !isNaN(preco) && preco > 0) {
        produto = new loja.Produto(nome, preco);
        nomeElemento.textContent = `Nome do Produto: ${produto.nome}`;
        precoElemento.textContent = `Preço: R$ ${produto.preco.toFixed(2)}`;
        precoFinalElemento.textContent = "";
        nomeInput.value = "";
        precoInput.value = "";
      } else {
        alert("Por favor, insira um nome e um preço válidos para o produto.");
      }
    };
  
    botaoCalcular.onclick = () => {
      if (produto) {
        const imposto = parseFloat(inputImposto.value);
  
        if (!isNaN(imposto)) {
          const precoFinal = produto.calcularPrecoFinal(imposto);
          precoFinalElemento.textContent = `Preço Final com Imposto: R$ ${precoFinal.toFixed(2)}`;
        } else {
          precoFinalElemento.textContent = "Por favor, insira um valor válido para o imposto.";
        }
      } else {
        precoFinalElemento.textContent = "Por favor, cadastre um produto primeiro.";
      }
    };
  };