"use strict";
window.onload = () => {
    let produto = null;
    const nomeInput = document.getElementById("nomeProduto");
    const precoInput = document.getElementById("precoProduto");
    const nomeElemento = document.getElementById("produtoNome");
    const precoElemento = document.getElementById("produtoPreco");
    const inputImposto = document.getElementById("inputImposto");
    const botaoCadastrar = document.getElementById("cadastrarProduto");
    const botaoCalcular = document.getElementById("calcularPreco");
    const precoFinalElemento = document.getElementById("precoFinal");
    botaoCadastrar.onclick = () => {
        const nome = nomeInput.value.trim();
        const preco = parseFloat(precoInput.value.trim());
        if (nome && !isNaN(preco) && preco > 0) {
            produto = new loja.Produto(nome, preco);
            nomeElemento.textContent = `Nome do Produto: ${produto.nome}`;
            precoElemento.textContent = `Preço: R$ ${produto.preco.toFixed(2)}`;
            precoFinalElemento.textContent = "";
            nomeInput.value = "";
            precoInput.value = "";
        }
        else {
            alert("Por favor, insira um nome e um preço válidos para o produto.");
        }
    };
    botaoCalcular.onclick = () => {
        if (produto) {
            const imposto = parseFloat(inputImposto.value);
            if (!isNaN(imposto)) {
                const precoFinal = produto.calcularPrecoFinal(imposto);
                precoFinalElemento.textContent = `Preço Final com Imposto: R$ ${precoFinal.toFixed(2)}`;
            }
            else {
                precoFinalElemento.textContent = "Por favor, insira um valor válido para o imposto.";
            }
        }
        else {
            precoFinalElemento.textContent = "Por favor, cadastre um produto primeiro.";
        }
    };
};
